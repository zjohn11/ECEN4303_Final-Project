**Important Final Project Note:

Any instance of Mux files are used for placeholders only, and thus will likely not LVS or simulate correctly.

Enable_DFF includes both the Mux and DFF together, both LVS and work as expected. 

Please only test Enable_DFF files for LVS and correct operation of Mux and DFF. 
